Client server
=============

start: `php -S localhost:80`

location: `localhost/server.php`

